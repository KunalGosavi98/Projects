import React from 'react';

function Dashboard()
{
    return(
      

      <div>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossOrigin="anonymous" />
        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" />
        <meta charSet="UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Document</title>
        <div className="wrapper">
          {/*Top Menu & Menu button*/}
          <div className="sidebar">
            <div className="profile">
             <img src="userProfile.png" alt="" />
               {/*<div class="img" style={{ 'background-image': 'url(assets/img/signup.png)' }}></div>*/}
              <h3>hello user</h3>
            </div>
            {/*Menu item*/}
            <ul>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-user-alt" /></span>
                  <span className="item">Update profile</span>
                </a>
              </li>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-folder" /></span>
                  <span className="item">Show Folders</span>
                </a>
              </li>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-share" /></span>
                  <span className="item">Share</span>
                </a>
              </li>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-power-off" /></span>
                  <span className="item">Logout</span>
                </a>
              </li>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-comments" /></span>
                  <span className="item">Contact Us</span>
                </a>
              </li>
              <li>
                <a href="#">
                  <span className="icon"><i className="fas fa-comments" /></span>
                  <span className="item">FAQ</span>
                </a>
              </li>
            </ul>
          </div>
          {/*top menu bar code started*/}
          <div className="section">
            <div className="top_navbar">
              <div className="logo">
                <img src="assets/img/Logo.png" alt="" />
              </div>
              <div>
                <h2 style={{color: 'black', marginLeft: '15px', fontFamily: '"Courier New", Courier, monospace'}}><b> Doc Locker</b></h2>
              </div>
              <div className="addfolder">
               
                  <span className="icon" type="button" ><i className="fas fa-folder-plus fa-3x" /></span>
                 
              </div>
              <div class="form-group d-md-flex">
              <div class="w-50 text-md-right" id="searchbar">
                <span className="icon" ><i className="fas fa-search" /></span>
                <input type="text" placeholder="Search" />
              </div>
              </div>
            </div>
            <div>
              <div className="background">
                <img src="https://media.istockphoto.com/photos/document-management-system-or-dms-automation-software-to-archiving-picture-id1349463167" alt="" />
                <div className="centered"><h1 style={{color: 'aliceblue'}}>Welcome User</h1><h3 style={{color: 'aliceblue'}}>“Feel easy,feel secure with Doc Locker</h3></div>
              </div>
            </div>
          </div>
        </div></div> 
    )
}
export default Dashboard