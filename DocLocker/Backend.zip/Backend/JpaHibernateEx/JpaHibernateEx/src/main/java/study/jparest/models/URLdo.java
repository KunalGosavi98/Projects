package study.jparest.models;

public class URLdo {

	String url;
	URLdo()
	{}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public URLdo(String url) {
		super();
		this.url = url;
	}
}
