package study.jparest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaHibernateExApplicationTests {

	@Test
	void contextLoads() {
	}

}
